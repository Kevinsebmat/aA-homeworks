# Write a recursive method `subsets(array)` that returns all of the subsets of 
# an array

# example => subsets([1,2,3])
# should return => [
#  [], 
#  [1], 
#  [2], 
#  [1, 2], 
#  [3], 
#  [1, 3], 
#  [2, 3], 
#  [1, 2, 3]
#  ]

def subsets(array)

end
